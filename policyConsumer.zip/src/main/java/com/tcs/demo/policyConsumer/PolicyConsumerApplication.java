package com.tcs.demo.policyConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolicyConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyConsumerApplication.class, args);
	}

}
