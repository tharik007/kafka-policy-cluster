package com.tcs.demo.policyConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
